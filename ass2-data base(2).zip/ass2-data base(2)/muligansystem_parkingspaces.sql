-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 100.76.110.20    Database: muligansystem
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `parkingspaces`
--

DROP TABLE IF EXISTS `parkingspaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parkingspaces` (
  `SpaceID` int NOT NULL,
  `ZoneID` int NOT NULL,
  `Occupied` varchar(255) DEFAULT NULL,
  `MaxTime` int DEFAULT NULL,
  PRIMARY KEY (`SpaceID`)
) ENGINE=ndbcluster DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parkingspaces`
--

LOCK TABLES `parkingspaces` WRITE;
/*!40000 ALTER TABLE `parkingspaces` DISABLE KEYS */;
INSERT INTO `parkingspaces` VALUES (3,301,'1',60),(6,301,'1',120),(7,301,'0',150),(9,301,'0',60),(10,301,'0',300),(15,302,'1',90),(16,302,'0',120),(17,302,'0',150),(18,302,'0',180),(20,302,'0',300),(23,303,'0',60),(24,303,'0',300),(26,303,'0',120),(28,303,'0',180),(29,303,'0',60),(31,304,'0',120),(34,304,'0',300),(36,304,'0',120),(37,304,'0',150),(41,305,'0',120),(43,305,'0',60),(47,305,'0',150),(50,305,'0',300),(52,306,'0',180),(53,306,'0',60),(55,306,'0',90),(57,306,'0',150),(60,306,'0',300),(62,307,'0',60),(63,307,'0',300),(65,307,'0',120),(67,307,'0',180),(69,307,'0',300),(70,307,'0',120),(72,308,'0',60),(73,308,'0',300),(76,308,'0',150),(77,308,'0',180),(79,308,'0',300),(80,308,'1',120),(82,309,'0',60),(85,309,'1',120),(87,309,'0',180),(90,309,'1',120),(91,310,'0',180),(92,310,'0',60),(93,310,'0',300),(95,310,'0',120),(99,310,'0',200),(100,310,'1',200),(1,301,'1',120),(2,301,'1',180),(4,301,'0',300),(5,301,'1',90),(8,301,'0',180),(11,302,'0',120),(12,302,'0',180),(13,302,'0',60),(14,302,'0',300),(19,302,'0',60),(21,303,'0',120),(22,303,'0',180),(25,303,'0',90),(27,303,'0',150),(30,303,'0',300),(32,304,'0',180),(33,304,'0',60),(35,304,'0',90),(38,304,'0',180),(39,304,'0',60),(40,304,'0',300),(42,305,'0',180),(44,305,'0',300),(45,305,'0',90),(46,305,'0',120),(48,305,'0',180),(49,305,'0',60),(51,306,'0',120),(54,306,'0',300),(56,306,'0',120),(58,306,'0',180),(59,306,'0',60),(61,307,'0',120),(64,307,'0',90),(66,307,'0',150),(68,307,'0',60),(71,308,'0',180),(74,308,'0',90),(75,308,'0',120),(78,308,'0',60),(81,309,'0',180),(83,309,'0',300),(84,309,'0',90),(86,309,'0',150),(88,309,'0',60),(89,309,'0',300),(94,310,'0',90),(96,310,'0',150),(97,310,'0',180),(98,310,'0',190);
/*!40000 ALTER TABLE `parkingspaces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-31  0:32:46
