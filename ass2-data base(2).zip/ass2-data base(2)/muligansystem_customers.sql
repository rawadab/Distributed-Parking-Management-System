-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 100.76.110.20    Database: muligansystem
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `CustomerID` int NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `TotalPaid` decimal(10,2) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=ndbcluster DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (46598723,'Isabella Lopez','0454896345','isabella.lopez@gmail.com',55.00,'1'),(65489327,'Emily Davis','0465869476','emily.davis@gmail.com',45.00,'3'),(125676354,'Daniel Wilson','0544876331','daniel.wilson2@gmail.com',30.00,'5'),(132148685,'William Martinez','0489653343','william.martinez@gmail.com',60.00,'7'),(315281964,'Rawad Abdalla','0505272254','Rawad.abdalla2@gmail.com',20.00,'9'),(369417634,'Maher batesh','0545656227','Maher.batesh@gmail.com',50.00,'10'),(465874651,'Alaa nwesyry','0254564556','Alaa.nwesyry@gmail.com',60.00,'14'),(46587373,'James Johnson','0654674976','james.johnson@gmail.com',48.00,'2'),(65852963,'Michael Brown','0116543684','michael.brown@gmail.com',90.00,'4'),(46578945,'Olivia Garcia','6545873353','olivia.garcia@gmail.com',30.00,'6'),(132556438,'John Doe','0543265863','john.doe@gmail.com',120.00,'8'),(465284334,'Mohamed jawad','0556467676','Mohamed.jawad@gmail.com',40.00,'11'),(452387764,'Sophia Miller','2316548579','sophia.miller@gmail.com',64.00,'12'),(465283045,'Daniel Wilson','0698536456','daniel.wilson@gmail.com',35.00,'13');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-31  0:32:46
